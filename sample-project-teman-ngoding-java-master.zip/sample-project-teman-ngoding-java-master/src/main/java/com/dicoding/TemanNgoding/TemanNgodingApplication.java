package com.dicoding.TemanNgoding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TemanNgodingApplication {

	public static void main(String[] args) {
		SpringApplication.run(TemanNgodingApplication.class, args);
	}

}
